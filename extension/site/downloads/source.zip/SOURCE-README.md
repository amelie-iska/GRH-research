# Research companion source archive

Start with README.md. The compiled paper is extension/manuscript/main.pdf;
its complete LaTeX project is in the same directory. The Lean files, actual
verification logs, CPU/GPU programs and results, mathematical claim register,
source reviews, and new interactive laboratories are included.

This compact archive excludes the duplicated legacy site and its large data
sets. Obtain the separate Complete_Repository.zip, or clone the pinned original
repository and overlay this archive, then run:

    python3 extension/code/prepare_legacy.py

The original Git submodules are recorded in .gitmodules; their full contents
are separate dependencies. Uploaded book scans, full OCR transcriptions and
downloaded third-party papers are not redistributed.

To serve the new laboratories locally, run:

    python3 -m http.server 8000 --directory extension/site

The downloads directory is generated during publication and is excluded from
this archive to avoid recursion. The manuscript is available directly above.
ARCHIVE-MANIFEST.json records a SHA-256 hash for every included source file.
The root .gitignore travels with the archive. Files named keys.txt and all
.private-credentials directories are excluded independently of Git tracking.
