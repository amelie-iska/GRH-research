# Exact formal interfaces

`BridgeTheorems.lean` contains 25 selected, typed theorem declarations for the
research extension. The file is deliberately limited to explicit elementary
interfaces. It does not formalize every theorem in the books or monograph.

The supplied build completed with exit code **0** for all 25 declarations.
`verification.log` records the actual Lean output, and `verification.json`
records the source hash, pinned dependency revision, declaration inventory, and
axiom dependencies. All printed dependencies are subsets of `propext`,
`Classical.choice`, and `Quot.sound`; none includes `sorryAx` or a project axiom.

## Reproduce with the pinned dependency

The local package uses Lean **4.24.0** and mathlib commit
`f897ebcf72cd16f89ab4577d0c826cd14afaafc7`.

From this directory, with the matching Lean toolchain installed:

```sh
lake update
lake exe cache get
lake env lean BridgeTheorems.lean
lake env lean QuantumInterfaces.lean
lake env lean DiagramGrammar.lean
lake env lean FluidInterfaces.lean
```

The last command prints the foundational axiom dependencies of every selected
declaration. The verification log and claim inventory are supplied separately.
An exit code of zero is required; source text alone is not a verification result.
The log must not contain `sorryAx` or project-specific unproved assumptions.
The standard Lean foundations, such as `propext`, `Quot.sound`, and
`Classical.choice`, are distinguished from an unproved mathematical claim.

An existing checkout of the same pinned mathlib commit can also provide the
environment without creating a second dependency checkout:

```sh
cd /absolute/path/to/pinned/mathlib
lake env lean /absolute/path/to/extension/lean/BridgeTheorems.lean
```

## What is formalized

| Family | Theorem content | Main hypotheses |
|---|---|---|
| Finite complexes | Image in kernel; rank bound; rank criterion for middle exactness | Linear maps over a field; zero composite; finite-dimensional middle space for dimension statements |
| Euler arithmetic | Rank terms cancel in the alternating sum | Integer dimension variables; this statement does not itself construct cohomology |
| Four-coordinate quadric | Exact perturbation expansion; tangent remainder; split quadratic coordinates; equal-radius equation | Commutative ring |
| Koszul identity | Two successive explicit maps compose to zero | Commutative ring; exactness is a stronger separate statement |
| Finite Hodge matrices | Positive semidefiniteness; quadratic energy; kernel test; characteristic determinant factorization | Real matrices; orthogonality condition for factorization |
| Small-energy family | Positive parameters with arbitrarily small energy in a fixed unit direction | Positive real tolerance |
| Integral shears | Determinant one; inverse; image and squared norm of the second basis vector | Integral matrix and real norm coordinates |
| Cyclic hidden relation | Kernel equation and collision-difference equation | `ZMod q`, including the general modulus allowed by its type |
| Linear encryption algebra | Matrix cancellation and a binary-selector noise estimate | Commutative coefficient ring for cancellation; real bounded errors for the estimate |

These proofs establish no runtime bound for a quantum algorithm, no lattice
hardness reduction, no global index theorem, and no continuum Yang–Mills
construction. Those distinctions are part of the theorem interfaces rather than
exceptions hidden in documentation.

## Additional quantum and binary-chain interfaces

`QuantumInterfaces.lean` contains **seven additional verified declarations**.
Its authentic output and independent inventory are in `quantum-verification.log`
and `quantum-verification.json`. The original 25-declaration manifest and
`BridgeTheorems.lean` hash remain unchanged. Both files are default Lake targets.
These first two files supply **32 selected declarations**. The second-pass
module below brings the total to **48**, without claiming a formalization of
the complete monograph.

The new file proves the square identities and anticommutation of actual 2-by-2
Pauli X/Z integer matrices. It defines the sign character of `ZMod 2`, proves
its multiplicativity, and derives the shift/phase commutation rule on actual
amplitude functions with values in any commutative ring. This specializes to
complex amplitudes without claiming an additional analytical Hilbert-space
theorem. For actual linear maps `d2 : C2 →ₗ[ZMod 2] C1` and
`d1 : C1 →ₗ[ZMod 2] C0` with zero composite, the resulting boundary shift and
coboundary phase commute. The proof derives their zero binary pairing from
the maps' composition; it does not assume the desired commutation as a premise.

The final theorem substitutes a separately justified Euler equation into an
integer rank formula. It does not itself prove surface classification,
cellular boundary ranks, encoded-qubit counts, or error-correction performance.
No full quantum circuit or QNN training procedure is claimed formalized.
Each new theorem has both a printed type and a printed axiom dependency list;
the successful build contains no `sorryAx` or project-specific axiom.

## Typed diagrams and transport: sixteen additional declarations

`DiagramGrammar.lean` and its `diagram-verification.log`/`.json` contain an
actually compiled typed sequential syntax, one-hole contexts, contextual
finite derivations, and explicit identity/associativity/inverse rules. The
semantics maps generators to actual linear maps. Equality of interpretation
is preserved by the verified rewrite rules and every finite derivation.

Separate declarations check finite matrix tensor interchange, tensor trace
factorization, rectangular trace cyclicity, the identity-loop dimension,
transport of complexes and exactness by actual linear equivalences, a
contracting-homotopy criterion for exactness, and the finite Hodge matrix
conjugacy identity under its displayed endpoint conditions. The middle
matrix must additionally be unitary for the manuscript's spectral reading.

All three modules are default Lake targets and all **48 declarations** were
freshly checked during the second pass. The raw outputs and source hashes
are preserved in `../review/second-pass-math-audit-core-kernel.*` and the
per-module manifests. The new source SHA-256 is
`871d34de90d99a263094f7abc4aadb51f5012d613c671b04fff43f5a0c35c1c6`.

The sequential syntax does not claim full tensor/dagger/traced graphical
coherence, channel CP/TP, measurements, QNN training, grammar completeness,
CCC, or natural-language understanding. Exact component mappings to the
manuscript appear in the mathematical claim register.

## Fluid dynamics: 34 additional declarations

`FluidInterfaces.lean` adds 34 actually checked declarations, bringing the
companion total to **82 across four default Lake targets**. The module checks
finite energy and actual coordinate derivatives, orthogonal projection,
boundary-flux continuity, Schur elimination, exact discrete memory, a forbidden
block composition, and the quadratic-order matrix used in the 2026
Navier–Stokes construction. `fluid-verification.json` and
`fluid-verification.log` preserve the successful check, exact types and source
hash; `fluid-axioms.log` preserves the axiom reports.

The module uses the same Lean 4.24.0/mathlib pin as the previous files and
introduces no project axiom or admitted placeholder. See
`../review/navier-stokes/formalization-review.md` for component scope.
It is separate from OpenAI's Lean 4.34.0-rc2 continuum development. The fresh
upstream build did not complete after dependency-cache rate limiting; the
upstream source audit is not described as a kernel verification.
